package com.example.sofe4640bookstore;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

public class AddNewBook extends AppCompatActivity {

    Button btnParse = null;
    HttpURLConnection conn= null;
    TextView jsonView;
    Spinner CategorySpinner;
    ArrayAdapter<CharSequence> CategoryAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_new_book);


        Intent recMsg = getIntent();
        String tempMsg = recMsg.getStringExtra("msg1");
        EditText isbnText = (EditText) findViewById(R.id.id_input);
        TextView txtview = (TextView) findViewById(R.id.lblMessage);
        txtview.setText(tempMsg);
        btnParse = (Button) findViewById(R.id.btnParse);
        jsonView = (TextView) findViewById(R.id.lblMessage);
        CategorySpinner = (Spinner) findViewById(R.id.category_input); // attach FixedInterestRateSpinner to FixedInterestRateSpinner found in activity_main.xml.
        CategoryAdapter = ArrayAdapter.createFromResource(this, R.array.CategoryList, android.R.layout.simple_spinner_item); // create adapter for InterestRateItems, which can be found in res/strings.xml.
        CategoryAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item); // sets the resource to a simple dropdown menu.
        CategorySpinner.setAdapter(CategoryAdapter); // connects the spinner to the adapter.
   btnParse.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            //"https://jsonparsingdemo-cec5b.firebaseapp.com/jsonData/moviesDemoItem.txt"
            JSONTask myTask = new JSONTask();
            EditText isbnText = (EditText) findViewById(R.id.isbnText);
            jsonView.setText("button pressed");
            myTask.execute("https://www.googleapis.com/books/v1/volumes?q="+isbnText.getText().toString());

        }
    });
}



class JSONTask extends AsyncTask<String, String, String>{

    @Override
    protected String doInBackground(String... strings) {

        try {
            URL url = new URL(strings[0]);
            conn = (HttpURLConnection) url.openConnection();
            conn.setReadTimeout(5000); //5 sec.
            conn.connect();
            if (conn.getResponseCode()== HttpURLConnection.HTTP_OK){

                InputStream stream = conn.getInputStream();
                BufferedReader reader = new BufferedReader( new InputStreamReader(stream));
                StringBuffer buffer = new StringBuffer();
                String line= "";
                while((line = reader.readLine()) != null){
                    buffer.append(line);
                }


                return buffer.toString();
            }
        } catch (MalformedURLException e) {
            e.printStackTrace();
            return null;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }finally {
            conn.disconnect();
        }
        return null;
    }

    @Override
    protected void onPostExecute(String result) {
        super.onPostExecute(result);
        //jsonView.setText(result.toString());

        //parsing Jason data
        String jsonString = result.toString();
        try {
            jsonView.setText("JSON successful");
            JSONObject jsonObject = new JSONObject(jsonString);
            JSONArray jsonArray = jsonObject.getJSONArray("items");
            JSONObject firstObj = jsonArray.getJSONObject(0);
            JSONObject volumeInfo = firstObj.getJSONObject("volumeInfo");
            String title = volumeInfo.getString("title");
            JSONArray authorsArray = volumeInfo.getJSONArray("authors");
            //JSONObject authorObj = authorsArray.getJSONObject(0);
            //String authors = "";// authorsArray.getString(0);
            ArrayList<String> authors = new ArrayList<String>();

            for (int i=0;i < authorsArray.length() ;i++) {
                    authors.add(authorsArray.getString(i));
                   // authors = authors +  authorsArray.getString(i) + ";"; //String.join(";",authorsArray.getString(i));
            }
            String publishedDate = volumeInfo.getString("publishedDate");
            String output = title + ", " + authors.toString() + ", " + publishedDate;

            jsonView.setText(output);

        } catch (JSONException e) {
            e.printStackTrace();
            jsonView.setText(e.getMessage());
        }
    }
}


}